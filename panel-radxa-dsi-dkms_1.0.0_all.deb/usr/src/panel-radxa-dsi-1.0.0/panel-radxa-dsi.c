// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright © 2023 Raspberry Pi Ltd
 *
 * Based on panel-raspberrypi-touchscreen by Broadcom
 */

#include <linux/delay.h>
#include <linux/module.h>
#include <linux/of.h>
#include <linux/regulator/consumer.h>

#include <video/mipi_display.h>

#include <drm/drm_crtc.h>
#include <drm/drm_mipi_dsi.h>
#include <drm/drm_modes.h>
#include <drm/drm_panel.h>

struct panel_cmd {
	char cmd;
	char data;
};

struct panel_desc {
	const struct drm_display_mode *mode;
	unsigned int bpc;
	unsigned int width_mm;
	unsigned int height_mm;

	unsigned long mode_flags;
	enum mipi_dsi_pixel_format format;
	unsigned int lanes;
	const struct panel_cmd *init_cmds;
	unsigned int init_cmds_num;
};

struct radxa_panel {
	struct drm_panel base;
	struct mipi_dsi_device *dsi;
	const struct panel_desc *desc;

	bool prepared;
	bool enabled;
};

static const struct panel_cmd radxa_8inch_cmds[] = {
	{ 0xe0, 0x00 },
	{ 0xe1, 0x93 },
	{ 0xe2, 0x65 },
	{ 0xe3, 0xf8 },
	{ 0x80, 0x03 },
	{ 0xe0, 0x01 },
	{ 0x00, 0x00 },
	{ 0x01, 0x72 },
	{ 0x03, 0x00 },
	{ 0x04, 0x65 },
	{ 0x0c, 0x74 },
	{ 0x17, 0x00 },
	{ 0x18, 0xb7 },
	{ 0x19, 0x00 },
	{ 0x1a, 0x00 },
	{ 0x1b, 0xb7 },
	{ 0x1c, 0x00 },
	{ 0x24, 0xfe },
	{ 0x37, 0x19 },
	{ 0x38, 0x05 },
	{ 0x39, 0x00 },
	{ 0x3a, 0x01 },
	{ 0x3b, 0x01 },
	{ 0x3c, 0x70 },
	{ 0x3d, 0xff },
	{ 0x3e, 0xff },
	{ 0x3f, 0xff },
	{ 0x40, 0x06 },
	{ 0x41, 0xa0 },
	{ 0x43, 0x1e },
	{ 0x44, 0x0f },
	{ 0x45, 0x28 },
	{ 0x4b, 0x04 },
	{ 0x55, 0x02 },
	{ 0x56, 0x01 },
	{ 0x57, 0xa9 },
	{ 0x58, 0x0a },
	{ 0x59, 0x0a },
	{ 0x5a, 0x37 },
	{ 0x5b, 0x19 },
	{ 0x5d, 0x78 },
	{ 0x5e, 0x63 },
	{ 0x5f, 0x54 },
	{ 0x60, 0x48 },
	{ 0x61, 0x45 },
	{ 0x62, 0x38 },
	{ 0x63, 0x3d },
	{ 0x64, 0x28 },
	{ 0x65, 0x43 },
	{ 0x66, 0x41 },
	{ 0x67, 0x43 },
	{ 0x68, 0x62 },
	{ 0x69, 0x50 },
	{ 0x6a, 0x57 },
	{ 0x6b, 0x49 },
	{ 0x6c, 0x44 },
	{ 0x6d, 0x37 },
	{ 0x6e, 0x23 },
	{ 0x6f, 0x10 },
	{ 0x70, 0x78 },
	{ 0x71, 0x63 },
	{ 0x72, 0x54 },
	{ 0x73, 0x49 },
	{ 0x74, 0x45 },
	{ 0x75, 0x38 },
	{ 0x76, 0x3d },
	{ 0x77, 0x28 },
	{ 0x78, 0x43 },
	{ 0x79, 0x41 },
	{ 0x7a, 0x43 },
	{ 0x7b, 0x62 },
	{ 0x7c, 0x50 },
	{ 0x7d, 0x57 },
	{ 0x7e, 0x49 },
	{ 0x7f, 0x44 },
	{ 0x80, 0x37 },
	{ 0x81, 0x23 },
	{ 0x82, 0x10 },
	{ 0xe0, 0x02 },
	{ 0x00, 0x47 },
	{ 0x01, 0x47 },
	{ 0x02, 0x45 },
	{ 0x03, 0x45 },
	{ 0x04, 0x4b },
	{ 0x05, 0x4b },
	{ 0x06, 0x49 },
	{ 0x07, 0x49 },
	{ 0x08, 0x41 },
	{ 0x09, 0x1f },
	{ 0x0a, 0x1f },
	{ 0x0b, 0x1f },
	{ 0x0c, 0x1f },
	{ 0x0d, 0x1f },
	{ 0x0e, 0x1f },
	{ 0x0f, 0x5f },
	{ 0x10, 0x5f },
	{ 0x11, 0x57 },
	{ 0x12, 0x77 },
	{ 0x13, 0x35 },
	{ 0x14, 0x1f },
	{ 0x15, 0x1f },
	{ 0x16, 0x46 },
	{ 0x17, 0x46 },
	{ 0x18, 0x44 },
	{ 0x19, 0x44 },
	{ 0x1a, 0x4a },
	{ 0x1b, 0x4a },
	{ 0x1c, 0x48 },
	{ 0x1d, 0x48 },
	{ 0x1e, 0x40 },
	{ 0x1f, 0x1f },
	{ 0x20, 0x1f },
	{ 0x21, 0x1f },
	{ 0x22, 0x1f },
	{ 0x23, 0x1f },
	{ 0x24, 0x1f },
	{ 0x25, 0x5f },
	{ 0x26, 0x5f },
	{ 0x27, 0x57 },
	{ 0x28, 0x77 },
	{ 0x29, 0x35 },
	{ 0x2a, 0x1f },
	{ 0x2b, 0x1f },
	{ 0x58, 0x40 },
	{ 0x59, 0x00 },
	{ 0x5a, 0x00 },
	{ 0x5b, 0x10 },
	{ 0x5c, 0x06 },
	{ 0x5d, 0x40 },
	{ 0x5e, 0x01 },
	{ 0x5f, 0x02 },
	{ 0x60, 0x30 },
	{ 0x61, 0x01 },
	{ 0x62, 0x02 },
	{ 0x63, 0x03 },
	{ 0x64, 0x6b },
	{ 0x65, 0x05 },
	{ 0x66, 0x0c },
	{ 0x67, 0x73 },
	{ 0x68, 0x09 },
	{ 0x69, 0x03 },
	{ 0x6a, 0x56 },
	{ 0x6b, 0x08 },
	{ 0x6c, 0x00 },
	{ 0x6d, 0x04 },
	{ 0x6e, 0x04 },
	{ 0x6f, 0x88 },
	{ 0x70, 0x00 },
	{ 0x71, 0x00 },
	{ 0x72, 0x06 },
	{ 0x73, 0x7b },
	{ 0x74, 0x00 },
	{ 0x75, 0xf8 },
	{ 0x76, 0x00 },
	{ 0x77, 0xd5 },
	{ 0x78, 0x2e },
	{ 0x79, 0x12 },
	{ 0x7a, 0x03 },
	{ 0x7b, 0x00 },
	{ 0x7c, 0x00 },
	{ 0x7d, 0x03 },
	{ 0x7e, 0x7b },
	{ 0xe0, 0x04 },
	{ 0x00, 0x0e },
	{ 0x02, 0xb3 },
	{ 0x09, 0x60 },
	{ 0x0e, 0x2a },
	{ 0x36, 0x59 },
	{ 0xe0, 0x00 },
	{ 0x80, 0x01 },
	{ 0xe0, 0x00 },
};

static inline struct radxa_panel *to_radxa_panel(struct drm_panel *panel)
{
	return container_of(panel, struct radxa_panel, base);
}

static int radxa_panel_init(struct radxa_panel *radxa, const struct panel_cmd *cmds)
{
	struct mipi_dsi_device *dsi = radxa->dsi;
	unsigned int i = 0;
	int ret;

	if (radxa->desc->init_cmds) {
		dsi->mode_flags |= MIPI_DSI_MODE_LPM;

		for (i = 0; i < radxa->desc->init_cmds_num; i++) {
			ret = mipi_dsi_dcs_write_buffer(dsi, &cmds[i], sizeof(struct panel_cmd));
			if (ret < 0)
				return ret;
		}
	}

	return 0;
}

static int radxa_panel_on(struct radxa_panel *radxa)
{
	struct mipi_dsi_device *dsi = radxa->dsi;
	struct device *dev = &radxa->dsi->dev;
	int ret;

	dsi->mode_flags |= MIPI_DSI_MODE_LPM;

	ret = mipi_dsi_dcs_exit_sleep_mode(dsi);
	if (ret < 0) {
		dev_err(dev, "failed to exit sleep mode: %d\n", ret);
		return ret;
	}

	msleep(120);

	ret = mipi_dsi_dcs_set_display_on(dsi);
	if (ret < 0)
		dev_err(dev, "failed to set display on: %d\n", ret);

	return ret;
}

static void radxa_panel_off(struct radxa_panel *radxa)
{
	struct mipi_dsi_device *dsi = radxa->dsi;
	struct device *dev = &radxa->dsi->dev;
	int ret;

	dsi->mode_flags &= ~MIPI_DSI_MODE_LPM;

	ret = mipi_dsi_dcs_set_display_off(dsi);
	if (ret < 0)
		dev_err(dev, "failed to set display off: %d\n", ret);

	ret = mipi_dsi_dcs_enter_sleep_mode(dsi);
	if (ret < 0)
		dev_err(dev, "failed to enter sleep mode: %d\n", ret);

	msleep(100);
}

static int radxa_panel_disable(struct drm_panel *panel)
{
	struct radxa_panel *radxa = to_radxa_panel(panel);

	if (!radxa->enabled)
		return 0;

	radxa->enabled = false;

	return 0;
}

static int radxa_panel_unprepare(struct drm_panel *panel)
{
	struct radxa_panel *radxa = to_radxa_panel(panel);

	if (!radxa->prepared)
		return 0;

	radxa_panel_off(radxa);

	radxa->prepared = false;

	return 0;
}

static int radxa_panel_prepare(struct drm_panel *panel)
{
	struct radxa_panel *radxa = to_radxa_panel(panel);
	struct device *dev = &radxa->dsi->dev;
	int ret;

	if (radxa->prepared)
		return 0;

	ret = radxa_panel_init(radxa, radxa->desc->init_cmds);
	if (ret < 0) {
		dev_err(dev, "failed to init panel: %d\n", ret);
		goto poweroff;
	}

	ret = radxa_panel_on(radxa);
	if (ret < 0) {
		dev_err(dev, "failed to set panel on: %d\n", ret);
		goto poweroff;
	}

	radxa->prepared = true;

	return 0;

poweroff:

	return ret;
}

static int radxa_panel_enable(struct drm_panel *panel)
{
	struct radxa_panel *radxa = to_radxa_panel(panel);

	if (radxa->enabled)
		return 0;

	radxa->enabled = true;

	return 0;
}

static const struct drm_display_mode radxa_panel_8inch_mode = {
		.clock = 70857,
		.hdisplay = 800,
		.hsync_start = 800 + 40,
		.hsync_end = 800 + 40 + 20,
		.htotal = 800 + 40 + 20 + 20,
		.vdisplay = 1280,
		.vsync_start = 1280 + 30,
		.vsync_end = 1280 + 30 + 4,
		.vtotal = 1280 + 30 + 4 + 28,
		.flags = 0,
};

static int radxa_panel_get_modes(struct drm_panel *panel,
				 struct drm_connector *connector)
{
	struct drm_display_mode *mode;
	struct radxa_panel *radxa = to_radxa_panel(panel);
	const struct drm_display_mode *m = radxa->desc->mode;
	struct device *dev = &radxa->dsi->dev;

	mode = drm_mode_duplicate(connector->dev, m);
	if (!mode) {
		dev_err(dev, "failed to add mode %ux%ux@%u\n",
			m->hdisplay, m->vdisplay, drm_mode_vrefresh(m));
		return -ENOMEM;
	}

	drm_mode_set_name(mode);

	drm_mode_probed_add(connector, mode);

	connector->display_info.width_mm = radxa->desc->width_mm;
	connector->display_info.height_mm = radxa->desc->height_mm;
	connector->display_info.bpc = radxa->desc->bpc;

	return 1;
}

static const struct drm_panel_funcs radxa_panel_funcs = {
	.disable = radxa_panel_disable,
	.unprepare = radxa_panel_unprepare,
	.prepare = radxa_panel_prepare,
	.enable = radxa_panel_enable,
	.get_modes = radxa_panel_get_modes,
};

static const struct panel_desc radxa_8inch_panel_desc = {
	.mode = &radxa_panel_8inch_mode,
	.bpc = 8,
	.width_mm = 107,
	.height_mm = 172,
	.mode_flags = MIPI_DSI_MODE_VIDEO_HSE | MIPI_DSI_MODE_VIDEO |
		      MIPI_DSI_CLOCK_NON_CONTINUOUS,
	.format = MIPI_DSI_FMT_RGB888,
	.lanes = 2,
	.init_cmds = radxa_8inch_cmds,
	.init_cmds_num = 171,
};

static const struct of_device_id radxa_of_match[] = {
	{
		.compatible = "radxa,8inch-panel",
		.data = &radxa_8inch_panel_desc,
	},
	{ }
};
MODULE_DEVICE_TABLE(of, radxa_of_match);

static int radxa_panel_add(struct radxa_panel *radxa)
{
	int ret;

	radxa->base.prepare_prev_first = true;
	drm_panel_init(&radxa->base, &radxa->dsi->dev, &radxa_panel_funcs,
		       DRM_MODE_CONNECTOR_DSI);

	ret = drm_panel_of_backlight(&radxa->base);
	if (ret)
		return ret;

	drm_panel_add(&radxa->base);

	return 0;
}

static void radxa_panel_del(struct radxa_panel *radxa)
{
	if (radxa->base.dev)
		drm_panel_remove(&radxa->base);
}

static int radxa_panel_probe(struct mipi_dsi_device *dsi)
{
	struct radxa_panel *radxa;
	const struct panel_desc *desc;
	int ret;

	radxa = devm_kzalloc(&dsi->dev, sizeof(*radxa), GFP_KERNEL);
	if (!radxa)
		return -ENOMEM;

	desc = of_device_get_match_data(&dsi->dev);
	dsi->mode_flags = desc->mode_flags;
	dsi->format = desc->format;
	dsi->lanes = desc->lanes;
	radxa->desc = desc;

	radxa->dsi = dsi;
	mipi_dsi_set_drvdata(dsi, radxa);

	ret = radxa_panel_add(radxa);
	if (ret < 0)
		return ret;

	ret = mipi_dsi_attach(dsi);
	if (ret < 0) {
		radxa_panel_del(radxa);
		return ret;
	}

	return 0;
}

static void radxa_panel_remove(struct mipi_dsi_device *dsi)
{
	struct radxa_panel *radxa = mipi_dsi_get_drvdata(dsi);
	int ret;

	ret = radxa_panel_disable(&radxa->base);
	if (ret < 0)
		dev_err(&dsi->dev, "failed to disable panel: %d\n", ret);

	ret = mipi_dsi_detach(dsi);
	if (ret < 0)
		dev_err(&dsi->dev, "failed to detach from DSI host: %d\n",
			ret);

	radxa_panel_del(radxa);
}

static void radxa_panel_shutdown(struct mipi_dsi_device *dsi)
{
	struct radxa_panel *radxa = mipi_dsi_get_drvdata(dsi);

	radxa_panel_disable(&radxa->base);
}

static struct mipi_dsi_driver radxa_panel_driver = {
	.driver = {
		.name = "panel-radxa-display",
		.of_match_table = radxa_of_match,
	},
	.probe = radxa_panel_probe,
	.remove = radxa_panel_remove,
	.shutdown = radxa_panel_shutdown,
};
module_mipi_dsi_driver(radxa_panel_driver);

MODULE_AUTHOR("Wentao <liuwentao@radxa.com>");
MODULE_DESCRIPTION("RADXA TOUCHSCREEN");
MODULE_LICENSE("GPL v2");
